# 🍽️ مطعم عبق التراثي الذكي

## نظرة عامة
مشروع ويب متكامل لمطعم تراثي ذكي يستخدم تقنيات الذكاء الاصطناعي لتحسين تجربة العملاء.

## الميزات الذكية 🤖

### 1. نظام التوصيات الذكي
- توصيات وجبات مخصصة بناءً على تفضيلات العميل
- اقتراحات ذكية حسب الموسم والطقس
- تحليل الطلبات السابقة

### 2. المساعد الافتراضي (شات بوت)
- مساعد ذكي للرد على استفسارات العملاء
- حجز الطاولات تلقائياً
- الإجابة عن أسئلة القائمة والمكونات

### 3. تحليل المراجعات بالذكاء الاصطناعي
- تحليل مشاعر العملاء من التعليقات
- استخراج الملاحظات الإيجابية والسلبية
- تقارير تلقائية عن رضا العملاء

### 4. التعرف على الأطباق بالصور
- رفع صورة الطبق والحصول على معلومات كاملة
- التعرف التلقائي على المكونات
- اقتراح أطباق مشابهة

### 5. نظام الطلب الصوتي
- الطلب عبر الأوامر الصوتية
- دعم اللغة العربية والإنجليزية
- تأكيد الطلب تلقائياً

### 6. التنبؤ بالطلبات
- توقع الطلبات المستقبلية بناءً على البيانات التاريخية
- إدارة المخزون الذكية
- تحسين جدولة الموظفين

## التقنيات المستخدمة 💻

### Frontend
- HTML5, CSS3, JavaScript (ES6+)
- تصميم متجاوب (Responsive Design)
- واجهة مستخدم تراثية عصرية
- رسوم متحركة سلسة

### Backend
- Node.js + Express.js
- RESTful API
- نظام مصادقة JWT
- معالجة الصور والملفات

### Database
- MongoDB (NoSQL)
- نماذج بيانات للوجبات، الطلبات، العملاء
- نظام التقييمات والمراجعات

### AI/ML Features
- TensorFlow.js للتعلم الآلي في المتصفح
- Speech Recognition API للأوامر الصوتية
- Image Recognition للتعرف على الأطباق
- Natural Language Processing للشات بوت

## هيكل المشروع 📁

```
abaq-restaurant/
├── frontend/           # الواجهة الأمامية
│   ├── index.html
│   ├── css/
│   ├── js/
│   └── assets/
├── backend/           # الخادم والAPI
│   ├── server.js
│   ├── routes/
│   ├── controllers/
│   ├── models/
│   └── middleware/
├── database/          # قاعدة البيانات
│   └── schema.js
└── README.md
```

## التثبيت والتشغيل 🚀

### المتطلبات
- Node.js (v14 أو أحدث)
- MongoDB (v4.4 أو أحدث)
- npm أو yarn

### خطوات التثبيت

1. **تحميل المشروع**
```bash
# تحميل المشروع
git clone https://github.com/your-username/abaq-restaurant.git
cd abaq-restaurant
```

2. **تثبيت حزم Backend**
```bash
cd backend
npm install
```

3. **إعداد قاعدة البيانات**
```bash
# تأكد من تشغيل MongoDB
mongod

# إنشاء قاعدة البيانات
mongo
use abaq_restaurant
```

4. **إعداد متغيرات البيئة**
```bash
# إنشاء ملف .env في مجلد backend
cp .env.example .env

# تحرير الملف وإضافة:
PORT=3000
MONGODB_URI=mongodb://localhost:27017/abaq_restaurant
JWT_SECRET=your_secret_key_here
```

5. **تشغيل المشروع**
```bash
# تشغيل Backend
cd backend
npm start

# في نافذة طرفية أخرى - تشغيل Frontend
cd frontend
# افتح index.html في المتصفح أو استخدم live-server
npx live-server
```

## الاستخدام 📱

### للعملاء
1. تصفح القائمة وعرض الأطباق
2. استخدام المساعد الذكي لطلب المساعدة
3. الطلب عبر الصوت أو النص
4. تتبع الطلب في الوقت الفعلي
5. تقييم الطعام والخدمة

### للإدارة
1. لوحة تحكم شاملة
2. إدارة القائمة والأطباق
3. تتبع الطلبات
4. تحليلات وتقارير ذكية
5. إدارة العملاء والحجوزات

## API Endpoints 🔌

### Authentication
- POST `/api/auth/register` - تسجيل مستخدم جديد
- POST `/api/auth/login` - تسجيل الدخول
- POST `/api/auth/logout` - تسجيل الخروج

### Menu
- GET `/api/menu` - عرض القائمة
- GET `/api/menu/:id` - عرض طبق محدد
- POST `/api/menu` - إضافة طبق (Admin)
- PUT `/api/menu/:id` - تحديث طبق (Admin)
- DELETE `/api/menu/:id` - حذف طبق (Admin)

### Orders
- GET `/api/orders` - عرض جميع الطلبات
- GET `/api/orders/:id` - عرض طلب محدد
- POST `/api/orders` - إنشاء طلب جديد
- PUT `/api/orders/:id` - تحديث حالة الطلب
- DELETE `/api/orders/:id` - إلغاء طلب

### AI Features
- POST `/api/ai/recommend` - توصيات ذكية
- POST `/api/ai/chatbot` - محادثة مع المساعد
- POST `/api/ai/image-recognition` - التعرف على الصورة
- POST `/api/ai/voice-order` - الطلب الصوتي
- POST `/api/ai/sentiment-analysis` - تحليل المشاعر

### Reviews
- GET `/api/reviews/:menuId` - عرض تقييمات طبق
- POST `/api/reviews` - إضافة تقييم
- PUT `/api/reviews/:id` - تحديث تقييم
- DELETE `/api/reviews/:id` - حذف تقييم

## الأمان 🔒

- تشفير كلمات المرور باستخدام bcrypt
- مصادقة JWT للجلسات
- حماية CORS
- تحقق من صحة المدخلات
- حماية من SQL Injection و XSS

## المساهمة 🤝

نرحب بالمساهمات! يرجى:
1. Fork المشروع
2. إنشاء فرع للميزة الجديدة
3. Commit التغييرات
4. Push للفرع
5. فتح Pull Request

## الترخيص 📄

هذا المشروع مرخص تحت MIT License

## الدعم 💬

للأسئلة والدعم:
- Email: support@abaq-restaurant.com
- Website: https://abaq-restaurant.com
- الهاتف: +970-XXX-XXXX

## الإصدار الحالي 📌

الإصدار: 2.0.0
تاريخ التحديث: 2026-02-02

---

صنع بـ ❤️ في فلسطين
