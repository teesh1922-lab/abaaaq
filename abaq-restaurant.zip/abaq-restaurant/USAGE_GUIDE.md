# 📋 دليل الاستخدام الكامل - مطعم عبق التراثي الذكي

## 🚀 البدء السريع

### المتطلبات الأساسية
- Node.js v14 أو أحدث
- MongoDB v4.4 أو أحدث
- npm أو yarn
- محرر نصوص (VS Code موصى به)

### خطوات التثبيت السريعة

#### 1. فك الضغط
```bash
unzip abaq-restaurant.zip
cd abaq-restaurant
```

#### 2. تثبيت Backend
```bash
cd backend
npm install
cp .env.example .env
# عدل ملف .env حسب إعداداتك
```

#### 3. تشغيل MongoDB
```bash
# على Windows
net start MongoDB

# على Linux/Mac
sudo systemctl start mongod
```

#### 4. تشغيل Backend
```bash
npm run dev
# الخادم سيعمل على http://localhost:3000
```

#### 5. تشغيل Frontend
```bash
cd ../frontend
# افتح index.html في المتصفح
# أو استخدم live-server
npx live-server
```

## 📁 هيكل المشروع

```
abaq-restaurant/
├── frontend/                 # الواجهة الأمامية
│   ├── index.html           # الصفحة الرئيسية
│   ├── css/                 # ملفات الأنماط
│   │   ├── style.css
│   │   ├── animations.css
│   │   └── responsive.css
│   ├── js/                  # ملفات JavaScript
│   │   ├── config.js        # الإعدادات
│   │   ├── utils.js         # دوال مساعدة
│   │   ├── ai-features.js   # ميزات الذكاء الاصطناعي
│   │   ├── menu.js          # إدارة القائمة
│   │   ├── cart.js          # إدارة السلة
│   │   ├── chatbot.js       # المساعد الذكي
│   │   ├── reservations.js  # الحجوزات
│   │   ├── reviews.js       # التقييمات
│   │   └── main.js          # الملف الرئيسي
│   └── assets/              # الصور والملفات
│
├── backend/                  # الخادم والAPI
│   ├── server.js            # الخادم الرئيسي
│   ├── package.json         # الحزم والتبعيات
│   ├── .env.example         # مثال متغيرات البيئة
│   ├── models/              # نماذج قاعدة البيانات
│   ├── routes/              # مسارات API
│   ├── controllers/         # المتحكمات
│   ├── middleware/          # البرمجيات الوسيطة
│   └── BACKEND_GUIDE.md     # دليل Backend
│
├── database/                 # قاعدة البيانات
│   └── schema.js            # المخططات والبيانات التجريبية
│
└── README.md                # الملف التوثيقي الرئيسي
```

## 🎯 الميزات الذكية

### 1. التوصيات الذكية 🧠
- **كيفية الاستخدام**: اضغط على "التوصيات الذكية" في قسم الميزات
- **الوظيفة**: يقترح أطباق مخصصة بناءً على:
  - تفضيلاتك السابقة
  - تقييمات العملاء
  - الأطباق الأكثر شعبية

### 2. المساعد الافتراضي 💬
- **كيفية الاستخدام**: اضغط على أيقونة الروبوت في الزاوية السفلى
- **الأسئلة المدعومة**:
  - "أريد حجز طاولة"
  - "ما هي ساعات العمل؟"
  - "أريد قائمة الطعام"
  - "أين موقعكم؟"

### 3. الطلب الصوتي 🎤
- **كيفية الاستخدام**: اضغط على أيقونة الميكروفون في الأعلى
- **أمثلة**:
  - "أريد طلب منسف"
  - "أضف كنافة إلى السلة"
  - "اعرض لي القائمة"

### 4. التعرف على الأطباق 📸
- **كيفية الاستخدام**: اضغط على "التعرف على الأطباق"
- **الوظيفة**: التقط صورة أي طبق واحصل على معلومات كاملة

### 5. تحليل المراجعات 📊
- **كيفية الاستخدام**: اضغط على "تحليل المراجعات"
- **الوظيفة**: يحلل مشاعر العملاء ويظهر إحصائيات

### 6. الحجز الذكي 🎯
- **كيفية الاستخدام**: اضغط على "اقتراح ذكي" في نموذج الحجز
- **الوظيفة**: يقترح أفضل الأوقات المتاحة حسب:
  - الازدحام المتوقع
  - تفضيلاتك السابقة
  - توفر الطاولات

## 🔧 الإعدادات المتقدمة

### تخصيص الألوان
عدل ملف `frontend/css/style.css`:
```css
:root {
    --primary-color: #8B4513;    /* لون أساسي */
    --secondary-color: #DAA520;  /* لون ثانوي */
    /* ... المزيد */
}
```

### تخصيص القائمة
عدل ملف `frontend/js/config.js`:
```javascript
SAMPLE_MENU: [
    {
        id: 1,
        name: 'اسم الطبق',
        category: 'main',
        price: 45.00,
        // ... المزيد
    }
]
```

### إضافة لغات جديدة
1. أضف ملف ترجمة في `frontend/js/i18n/`
2. عدل `config.js` لإضافة اللغة
3. استخدم الدوال المساعدة للترجمة

## 🔐 الأمان

### للبيئة الإنتاجية

1. **تغيير JWT_SECRET**:
```bash
JWT_SECRET=$(openssl rand -base64 32)
```

2. **تفعيل HTTPS**:
   - استخدم Let's Encrypt
   - عدل إعدادات Express

3. **حماية قاعدة البيانات**:
   - استخدم مستخدم MongoDB محدود الصلاحيات
   - فعّل المصادقة

4. **Rate Limiting**:
   - معدل الطلبات محدود بـ 100 طلب/15 دقيقة
   - يمكن التعديل في `.env`

## 🌐 النشر (Deployment)

### على Heroku
```bash
heroku create abaq-restaurant
heroku addons:create mongolab
git push heroku main
```

### على DigitalOcean
```bash
# SSH إلى الخادم
ssh root@your-server-ip

# نصب Node.js و MongoDB
apt update
apt install nodejs npm mongodb

# رفع الملفات
scp -r abaq-restaurant root@your-server-ip:/var/www/

# تشغيل كخدمة
pm2 start backend/server.js
```

### على Vercel (Frontend فقط)
```bash
cd frontend
vercel
```

## 🐛 حل المشاكل الشائعة

### المشكلة: لا يعمل الخادم
**الحل**:
```bash
# تأكد من تشغيل MongoDB
mongod --version

# تأكد من المنفذ
netstat -ano | findstr :3000

# أعد تثبيت الحزم
rm -rf node_modules package-lock.json
npm install
```

### المشكلة: خطأ في الاتصال بقاعدة البيانات
**الحل**:
```bash
# تأكد من تشغيل MongoDB
sudo systemctl status mongod

# اختبر الاتصال
mongo
> show dbs

# تحقق من MONGODB_URI في .env
```

### المشكلة: CORS Error
**الحل**:
عدل `backend/server.js`:
```javascript
app.use(cors({
    origin: 'http://localhost:8080', // عنوان Frontend
    credentials: true
}));
```

## 📱 التطبيق على الموبايل

### تحويل لتطبيق Android/iOS
يمكن استخدام:
- React Native
- Flutter
- Ionic
- Capacitor

### PWA (Progressive Web App)
أضف `manifest.json` و Service Worker للعمل offline

## 🧪 الاختبار

### Frontend Testing
```bash
cd frontend
npm install --save-dev jest
npm test
```

### Backend Testing
```bash
cd backend
npm test
```

### E2E Testing
```bash
npm install --save-dev cypress
npx cypress open
```

## 📊 المراقبة والتحليلات

### إضافة Google Analytics
```html
<!-- في index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
```

### مراقبة الأداء
- استخدم PM2 للمراقبة
- New Relic للتحليلات
- Sentry للأخطاء

## 🔄 التحديثات المستقبلية

### مخطط التطوير
- [ ] إضافة الدفع الإلكتروني
- [ ] تطبيق موبايل
- [ ] نظام الولاء والنقاط
- [ ] التكامل مع Google Maps
- [ ] إشعارات Push
- [ ] وضع Dark Mode
- [ ] دعم لغات متعددة

## 💡 نصائح للتطوير

1. **استخدم Git للإصدارات**:
```bash
git init
git add .
git commit -m "Initial commit"
```

2. **اتبع معايير الكود**:
   - ESLint للـ JavaScript
   - Prettier للتنسيق

3. **اكتب تعليقات واضحة**:
```javascript
// ❌ سيء
const x = a + b;

// ✅ جيد
// حساب المجموع الكلي للطلب
const totalPrice = itemPrice + taxAmount;
```

4. **استخدم async/await بدلاً من callbacks**

5. **احفظ نسخ احتياطية منتظمة**

## 📞 الدعم والمساعدة

### الحصول على المساعدة
- **البريد الإلكتروني**: support@abaq-restaurant.com
- **GitHub Issues**: github.com/abaq-restaurant/issues
- **الوثائق**: docs.abaq-restaurant.com

### المساهمة في المشروع
1. Fork المشروع
2. أنشئ فرع جديد (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push للفرع (`git push origin feature/amazing-feature`)
5. افتح Pull Request

## 📜 الترخيص

هذا المشروع مرخص تحت MIT License - انظر ملف LICENSE للتفاصيل

## 🙏 شكر وتقدير

- Font Awesome للأيقونات
- Google Fonts للخطوط
- Unsplash للصور
- جميع المساهمين في المشروع

---

**صنع بـ ❤️ في فلسطين**

لأي استفسارات أو دعم، لا تتردد في التواصل معنا!

الإصدار: 2.0.0
آخر تحديث: 2026-02-02
