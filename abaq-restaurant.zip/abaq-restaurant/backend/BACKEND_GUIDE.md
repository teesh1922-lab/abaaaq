# ملفات Backend المتبقية - دليل التطوير

## نماذج قاعدة البيانات (Models)

### 1. User.js
```javascript
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: String,
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ['customer', 'admin'], default: 'customer' },
    preferences: Object,
    createdAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
});

module.exports = mongoose.model('User', userSchema);
```

### 2. Menu.js
```javascript
const mongoose = require('mongoose');

const menuSchema = new mongoose.Schema({
    name: { type: String, required: true },
    category: { type: String, required: true },
    price: { type: Number, required: true },
    description: String,
    image: String,
    ingredients: [String],
    rating: { type: Number, default: 0 },
    reviews: { type: Number, default: 0 },
    isAvailable: { type: Boolean, default: true },
    isVegan: Boolean,
    isSpicy: Boolean,
    calories: Number,
    preparationTime: Number,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Menu', menuSchema);
```

### 3. Order.js
```javascript
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    items: [{
        menu: { type: mongoose.Schema.Types.ObjectId, ref: 'Menu' },
        quantity: Number,
        price: Number
    }],
    total: { type: Number, required: true },
    status: { 
        type: String, 
        enum: ['pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled'],
        default: 'pending' 
    },
    deliveryAddress: String,
    phone: String,
    notes: String,
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', orderSchema);
```

### 4. Reservation.js
```javascript
const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    name: { type: String, required: true },
    phone: { type: String, required: true },
    date: { type: Date, required: true },
    time: { type: String, required: true },
    guests: { type: Number, required: true },
    section: String,
    notes: String,
    status: { 
        type: String, 
        enum: ['pending', 'confirmed', 'cancelled', 'completed'],
        default: 'pending' 
    },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Reservation', reservationSchema);
```

### 5. Review.js
```javascript
const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    menu: { type: mongoose.Schema.Types.ObjectId, ref: 'Menu' },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, required: true },
    sentiment: { type: String, enum: ['positive', 'neutral', 'negative'] },
    helpful: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Review', reviewSchema);
```

## Routes (المسارات)

### 1. auth.js
```javascript
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/logout', authController.logout);
router.get('/me', authController.protect, authController.getMe);

module.exports = router;
```

### 2. menu.js
```javascript
const express = require('express');
const router = express.Router();
const menuController = require('../controllers/menuController');
const auth = require('../middleware/auth');

router.get('/', menuController.getAll);
router.get('/:id', menuController.getById);
router.post('/', auth.protect, auth.restrictTo('admin'), menuController.create);
router.put('/:id', auth.protect, auth.restrictTo('admin'), menuController.update);
router.delete('/:id', auth.protect, auth.restrictTo('admin'), menuController.delete);

module.exports = router;
```

### 3. ai.js
```javascript
const express = require('express');
const router = express.Router();
const aiController = require('../controllers/aiController');

router.post('/recommend', aiController.getRecommendations);
router.post('/chatbot', aiController.chatbot);
router.post('/image-recognition', aiController.imageRecognition);
router.post('/voice-order', aiController.voiceOrder);
router.post('/sentiment-analysis', aiController.sentimentAnalysis);

module.exports = router;
```

## Controllers (المتحكمات)

### authController.js
```javascript
const User = require('../models/User');
const jwt = require('jsonwebtoken');

exports.register = async (req, res) => {
    try {
        const user = await User.create(req.body);
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
        res.status(201).json({ success: true, token, user });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email }).select('+password');
        
        if (!user || !(await user.comparePassword(password))) {
            return res.status(401).json({ message: 'بيانات دخول خاطئة' });
        }
        
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
        res.json({ success: true, token, user });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};
```

### aiController.js
```javascript
exports.getRecommendations = async (req, res) => {
    try {
        // AI logic for recommendations
        const recommendations = await Menu.find()
            .sort({ rating: -1 })
            .limit(4);
        res.json({ success: true, data: recommendations });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

exports.chatbot = async (req, res) => {
    try {
        const { message } = req.body;
        // Simple chatbot logic
        const response = getAIResponse(message);
        res.json({ success: true, response });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};

exports.sentimentAnalysis = async (req, res) => {
    try {
        const { text } = req.body;
        // Simple sentiment analysis
        const sentiment = analyzeSentiment(text);
        res.json({ success: true, sentiment });
    } catch (error) {
        res.status(400).json({ success: false, message: error.message });
    }
};
```

## Middleware

### auth.js
```javascript
const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.protect = async (req, res, next) => {
    try {
        let token;
        if (req.headers.authorization?.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }
        
        if (!token) {
            return res.status(401).json({ message: 'غير مصرح' });
        }
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await User.findById(decoded.id);
        next();
    } catch (error) {
        res.status(401).json({ message: 'رمز غير صالح' });
    }
};

exports.restrictTo = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ message: 'غير مسموح' });
        }
        next();
    };
};
```

## ملاحظات التطوير

1. **تثبيت الحزم**: 
   ```bash
   cd backend
   npm install
   ```

2. **إعداد البيئة**:
   - انسخ `.env.example` إلى `.env`
   - عدل القيم حسب بيئتك

3. **تشغيل المشروع**:
   ```bash
   npm run dev
   ```

4. **للإنتاج**:
   ```bash
   npm start
   ```

5. **اختبار API**:
   - استخدم Postman أو Insomnia
   - الـ Base URL: http://localhost:3000/api

## Security Best Practices

- استخدم متغيرات بيئة آمنة
- فعّل HTTPS في الإنتاج
- استخدم Rate Limiting
- تحقق من المدخلات
- استخدم Helmet للحماية
- فعّل CORS بشكل صحيح

## Database Schema

يمكنك تصدير البيانات التجريبية باستخدام:
```bash
mongoimport --db abaq_restaurant --collection menus --file sample_menu.json
```

## AI Features Integration

للميزات الذكية الكاملة، يمكنك دمج:
- OpenAI API للشات بوت المتقدم
- Google Vision API للتعرف على الصور
- TensorFlow للتوصيات الذكية
- NLP libraries لتحليل المشاعر

## قواعد البيانات الإضافية

يمكنك إضافة:
- جداول للعروض والخصومات
- جداول للموظفين
- جداول لسجلات المخزون
- جداول للإحصائيات

## API Documentation

يمكن إضافة Swagger/OpenAPI للتوثيق التلقائي
