// ====================================
// Database Schema and Sample Data
// ====================================

const mongoose = require('mongoose');

// Sample Data for Development
const sampleData = {
    users: [
        {
            name: 'أحمد محمود',
            email: 'ahmad@example.com',
            phone: '+970599123456',
            password: 'password123',
            role: 'customer'
        },
        {
            name: 'مدير المطعم',
            email: 'admin@abaq-restaurant.ps',
            phone: '+970599999999',
            password: 'admin123',
            role: 'admin'
        }
    ],

    menu: [
        {
            name: 'المنسف الأردني',
            category: 'main',
            price: 45.00,
            description: 'طبق تراثي شهير من لحم الخروف مع الأرز واللبن الجميد',
            image: 'mansaf.jpg',
            ingredients: ['لحم خروف', 'أرز', 'لبن جميد', 'بهارات'],
            rating: 4.8,
            reviews: 156,
            isAvailable: true,
            preparationTime: 45,
            calories: 650
        },
        {
            name: 'المقلوبة الفلسطينية',
            category: 'main',
            price: 38.00,
            description: 'أرز مع الخضار واللحم أو الدجاج مقلوب بطريقة تقليدية',
            image: 'maqluba.jpg',
            ingredients: ['دجاج', 'أرز', 'باذنجان', 'قرنبيط', 'بهارات'],
            rating: 4.9,
            reviews: 203,
            isAvailable: true,
            preparationTime: 40,
            calories: 580
        },
        {
            name: 'الكنافة النابلسية',
            category: 'desserts',
            price: 20.00,
            description: 'حلوى تراثية من الكنافة بالجبنة والقطر',
            image: 'kanafeh.jpg',
            ingredients: ['كنافة', 'جبنة', 'قطر', 'سمنة', 'فستق'],
            rating: 5.0,
            reviews: 421,
            isAvailable: true,
            preparationTime: 20,
            calories: 450
        }
    ],

    reservations: [
        {
            name: 'محمد علي',
            phone: '+970599111222',
            date: new Date('2026-02-10'),
            time: '19:00',
            guests: 4,
            section: 'indoor',
            status: 'confirmed'
        }
    ],

    reviews: [
        {
            rating: 5,
            comment: 'تجربة رائعة! الطعام لذيذ جداً والخدمة ممتازة.',
            sentiment: 'positive'
        },
        {
            rating: 4,
            comment: 'طعام تراثي أصيل بجودة عالية. الأسعار معقولة.',
            sentiment: 'positive'
        }
    ]
};

// Database Indexes for Performance
const indexes = {
    users: [
        { email: 1 },
        { phone: 1 },
        { createdAt: -1 }
    ],
    menu: [
        { category: 1 },
        { rating: -1 },
        { price: 1 },
        { isAvailable: 1 }
    ],
    orders: [
        { user: 1 },
        { status: 1 },
        { createdAt: -1 }
    ],
    reservations: [
        { date: 1, time: 1 },
        { status: 1 },
        { user: 1 }
    ],
    reviews: [
        { menu: 1 },
        { user: 1 },
        { rating: -1 },
        { createdAt: -1 }
    ]
};

// Initialization Function
async function initializeDatabase() {
    try {
        console.log('🔄 جاري تهيئة قاعدة البيانات...');

        // Check if data already exists
        const User = mongoose.model('User');
        const userCount = await User.countDocuments();

        if (userCount > 0) {
            console.log('✅ قاعدة البيانات تحتوي على بيانات بالفعل');
            return;
        }

        // Insert sample data
        const Menu = mongoose.model('Menu');
        const Reservation = mongoose.model('Reservation');
        const Review = mongoose.model('Review');

        // await User.insertMany(sampleData.users);
        await Menu.insertMany(sampleData.menu);
        await Reservation.insertMany(sampleData.reservations);
        // await Review.insertMany(sampleData.reviews);

        console.log('✅ تم إدخال البيانات التجريبية بنجاح');

        // Create indexes
        console.log('🔄 جاري إنشاء الفهارس...');
        
        for (const [collection, indexList] of Object.entries(indexes)) {
            const model = mongoose.model(collection.charAt(0).toUpperCase() + collection.slice(1, -1));
            for (const index of indexList) {
                await model.createIndexes(index);
            }
        }

        console.log('✅ تم إنشاء الفهارس بنجاح');
        console.log('✨ قاعدة البيانات جاهزة للاستخدام!');

    } catch (error) {
        console.error('❌ خطأ في تهيئة قاعدة البيانات:', error);
        throw error;
    }
}

// Export
module.exports = {
    sampleData,
    indexes,
    initializeDatabase
};
